pref("certpatrol.popup.new", false);
pref("certpatrol.popup.change", false);
pref("certpatrol.popup.wild", false);
pref("certpatrol.privatebrowsing.save", false);
pref("certpatrol.notify.new", true);
pref("certpatrol.notify.wild", true);
pref("certpatrol.notify.timeout", 10);
pref("certpatrol.hosts.ignore", "si0.twimg.com");

// See http://kb.mozillazine.org/Localize_extension_descriptions
pref("extensions.CertPatrol@PSYC.EU.description", "chrome://certpatrol/locale/CertPatrol.properties");

//show debug messages?
//pref("extensions.CertPatrol@PSYC.EU.debug", false);
